﻿** Практическое занятие 13. Диагностика регрессии.
** Анализ данных -1, НИУ ВШЭ, ф-т социологии, А.Р.Бессуднов, 2012
** Материал основан на http://www.ats.ucla.edu/stat/spss/webbooks/reg/chapter2/spssreg2.htm

FILE HANDLE crime name = 'D:\hse\courses2011\introdatanal\lectures\lecture5\complab\crime.sav'.
GET FILE = crime.

**  Переменные:
** sid -- id штата,
** state -- название штата,
** crime -- число насильственных преступлений на 100000 жителей,
** murder -- число убийств на 1 млн жителей,
** pctmetro -- процент населения, живущего в метрополиях,
** pctwhite -- процент белого населения,
** pcths -- процент населения с законченным средним образованием,
** single -- процент одиноких родителей.

descriptives
  /var=crime murder pctmetro pctwhite pcths poverty single.

** Диаграммы рассеивания.

GRAPH /SCATTERPLOT(BIVAR)=pctmetro WITH crime BY state(name) .
GRAPH /SCATTERPLOT(BIVAR)=poverty WITH crime BY state(name) .
GRAPH /SCATTERPLOT(BIVAR)=single WITH crime BY state(name) .


** Уровень преступности <- процент городского населения, бедность, процент одиноких родителей.

regression
  /dependent crime
  /method=enter pctmetro poverty single.

** Гистрограмма остатков.

regression
  /dependent crime
  /method=enter pctmetro poverty single
	/residuals=histogram.

** Гистограмма остатков, статистика по 10 наблюдениям с наибольшими остатками.

regression
  /dependent crime
  /method=enter pctmetro poverty single
  /residuals=histogram(sdresid) id(state) outliers(sdresid).


** Наблюдения со стандартизованными остатками больше 2.

regression
  /dependent crime
  /method=enter pctmetro poverty single
  /residuals=histogram(sdresid) id(state) outliers(sdresid)
  /casewise=plot(sdresid) outliers(2)  .

** "Рычаг", диаграмма рассеивания "рычага" и остатков.

regression
  /dependent crime
  /method=enter pctmetro poverty single
  /residuals=histogram(sdresid lever) id(state) outliers(sdresid, lever)
  /casewise=plot(sdresid)  outliers(2)
  /scatterplot(*lever, *sdresid).

** D Кука

regression
  /dependent crime
  /method=enter pctmetro poverty single
  /residuals=histogram(sdresid lever) id(state) outliers(sdresid, lever, cook)
  /casewise=plot(sdresid)  outliers(2) cook dffit
  /scatterplot(*lever, *sdresid).

** DFBETA

regression
  /dependent crime
  /method=enter pctmetro poverty single
  /residuals=histogram(sdresid lever) id(state) outliers(sdresid, lever, cook)
  /casewise=plot(sdresid)  outliers(2) cook dffit
  /scatterplot(*lever, *sdresid)
  /save sdbeta(sdfb).

** Графическое отображение DFBETA

VARIABLE LABLES sdfb1 "Sdfbeta pctmetro"
                              /sdfb2 "Sdfbeta poverty"
                              /sdfb3 "Sdfbeta single" .

GRAPH
  /SCATTERPLOT(OVERLAY)=sid sid sid  WITH sdfb1 sdfb2 sdfb3 (PAIR) BY state(name)
  /MISSING=LISTWISE .

** Критические значения.

** рычаг	>(2k+2)/n
** стандартизованные остатки (по модулю) > 2
*** D	Кука > 4/n
*** DFBETA (по модулю) > 2/sqrt(n)

** Графики частной регрессии.

regression
  /dependent crime
  /method=enter pctmetro poverty single
  /residuals=histogram(sdresid lever) id(state) outliers(sdresid, lever, cook)
  /casewise=plot(sdresid)  outliers(2) cook dffit
  /scatterplot(*lever, *sdresid)
  /partialplot.

** Регрессия с данными для Вашингтона и без них.

regression
  /dependent crime
  /method=enter pctmetro poverty single.

compute filtvar = (state NE "dc").
filter by filtvar.
regression
  /dependent crime
  /method=enter pctmetro poverty single . 
filter off.

**** Нормальность распределения остатков.

regression
  /dependent crime
  /method=enter pctmetro poverty single
		/save resid(resid1).

examine
  variables=resid1
  /plot boxplot stemleaf histogram npplot.

** Гетероскедастичность.

regression
  /dependent crime
  /method=enter pctmetro poverty single
/scatterplot(*zresid *pred).

** Мультиколлинеарность.

regression
/statistics=defaults tol
  /dependent crime
  /method=enter pctmetro poverty single.



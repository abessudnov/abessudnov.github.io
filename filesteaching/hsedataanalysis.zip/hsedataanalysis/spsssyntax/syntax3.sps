﻿** A.Р.Бессуднов, "Анализ данных", НИУ ВШЭ, факультет социологии, 2012, группа 233.
** Практические занятия 7-9. Линейная регрессия и корреляция.

** Данные О.Д.Данкана о профессиональном престиже в США (1961).
** Источник: : Duncan, O. D. (1961) A socioeconomic index for all occupations. In Reiss, A. J., 
Jr. (Ed.) Occupations and Social Status. Free Press [Table VI-1].  
** J.Fox's website, http://socserv.socsci.mcmaster.ca/jfox/Books/Applied-Regression-2E/datasets/Duncan.txt
** Переменные:
** occup -- профессия,
** prestige -- % респондентов в опросе NORC, которые оценили уровень престижа данной профессии 
** как хороший или превосходный,
** income -- % мужчин в данной профессии, которые в 1950 г. зарабатывали больше 3500,
** education -- % мужчин в данной профессии в 1950 г., закончивших среднюю школу.
** type -- тип профессии (специалисты, "белые воротнички", "синие воротнички")

FILE HANDLE duncan name = 'D:\hse\courses2011\introdatanal\lectures\lecture3\seminar\duncan.sav'.
GET FILE = duncan.

desc var=all.

** Диаграмма рассеивания: престиж vs. образование.

graph
	/scatterplot(bivar) education with prestige.

** Регрессия: престиж <- образование

regression
	/dependent = prestige
	/method=enter education.

** Корреляция: престиж и образование.

correlations variables= prestige education.

** Престиж и доход.

graph
	/scatterplot(bivar) income with prestige.

regression
	/dependent = prestige
	/method=enter income.

** Престиж <- образование и доход.

correlations variables= prestige education income.

regression
	/dependent = prestige
	/method=enter income education.

** 3D диаграмма рассеивания.

*** Категориальные независимые переменные.

AUTORECODE VARIABLES=type /INTO type_num.
freq var=type_num.

** Дихотомические переменные.
** Сначала перекодируем type_num в дихотомическую переменную (специалисты vs. белые и синие воротнички).

recode type_num (1 3=0) (2=1) into prof.
exe.

regression
	/dependent = prestige
	/method=enter prof.

** Среднее значение prestige в двух группах.

means tables=prestige by prof.
t-test groups=prof(0,1) /variables=prestige.

** Задание 1. Файл abortions.sav содержит следующие  данные по регионам России:
** urban -- процент городского населения (2008),
** wealth -- индикатор материальных ресурсов (средние ресурсы, доступные домохозяйству (руб),
** деленные на прожиточный минимум в регионе (2008).
** cohab -- процент пар, живущих вместе, но не зарегистрирвавших брак (2008).
** abort -- коэффициент абортов (число абортов на 1000 женщин в возрасте 15-49 лет) (2008)
** northcauc -- фиктивная переменная для северокавказских регионов
** name -- название региона.

** Постройте диаграммы рассеивания: abort -- wealth, abort -- urban, abort -- cohab.
** Оцените регрессионную модель зависимости коэффициента абортов от уровня урбанизации,
** материальных ресурсов, процента незарегистрированных браков и принадлежности региона к Северному Кавказу.



***********************************************************************************************************************

FILE HANDLE duncan name = 'D:\hse\courses2011\introdatanal\lectures\lecture3\seminar\duncan.sav'.
GET FILE = duncan.

** Категориальный предиктор с большим количеством категорий.

if type_num NE missing(type_num) type1=0.
if type_num = 1 type1 = 1.
if type_num NE missing(type_num) type2=0.
if type_num = 2 type2 = 1.
if type_num NE missing(type_num) type3=0.
if type_num = 3 type3 = 1.
exe.

list type_num type1 type2 type3.

** То же самое с помощью цикла.

do repeat A=type1 type2 type3
 /B=1 2 3.
compute A=(type_num=B).
end repeat.

list type_num type1 type2 type3.

regression
	/dependent = prestige
	/method=enter type2 type3.

regression
	/dependent = prestige
	/method=enter income education type2 type3.

glm
 prestige by type_num
	with income education
	/design  type_num income education
	/print=parameter.

***** Задание 2.
** 2.1. Для российской выборке на данных ESS оцените модель связи между уровнем счастья (переменная
** happy) и полом, возрастом, образованием и регионом (некоторые переменные потребуется
** перекодировать).. Проинтерпретируйте регрессионные коэффициенты. Какие из них статистически 
** значимы, а какие нет?
** 2.2. Оцените ту же модель для переменной удовлетворенность жизнью (stflife). Что изменилось?
** 2.3. Оцените связь уровня религиозности (rlgdgr) с полом, возрастом, уровнем образования и страной
** (для всей выборки).

FILE HANDLE ess name = 'D:\hse\courses2011\introdatanal\lectures\lecture2\seminar\class1ess.sav'.
GET FILE = ess.

AUTORECODE VARIABLES=cntry /INTO cntr_num.
recode cntr_num (18=1) (else=0) into rus.
exe.
filter by rus.

recode gndr (1=1) (2=0) into male.
freq var=eisced.
recode eisced (1 2=1) (4=2) (5=3) (6 7=4) into educ.
freq var=region.
exe.

glm
 happy by educ region
	with agea male
	/design educ region agea male
	/print=parameter.

glm
 stflife by educ region
	with agea male
	/design educ region agea male
	/print=parameter.

**************************************************

** Данные ESS по России за 2010 г.

FILE HANDLE essru name = 'D:\hse\courses2011\introdatanal\lectures\lecture3\seminar\ess2010ru.sav'.
GET FILE = essru.


correlations variables= ppltrst trstprl trstlgl trstplc trstplt trstprt.

** Постройте модель зависимости уровня доверия к людям от пола, возраста, образования, дохода и региона..
** То же самое для уровня религиозности.



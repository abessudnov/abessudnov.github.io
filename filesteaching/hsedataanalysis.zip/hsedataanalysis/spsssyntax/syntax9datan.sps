﻿** Дисперсионный анализ, 28 мая 2012 г.
** А.Р.Бессуднов, Анализ социологических данных - 1, факультет социологии НИУ ВШЭ, 2-й курс

** Данные: образование и доход по трем расовым группам
** Источник: A.Agresti, B.Finlay, Statistical Methods for the Social Sciences
** http://www.stat.ufl.edu/~aa/social/data.html

FILE HANDLE incrace name = 'D:\hse\courses2011\introdatanal\lectures\lecture9\complab\incrace.sav'.
GET FILE = incrace.

* Файл содержит три переменные: доход, образование (интервальные) и расово-этническая группа
* (категориальная).

** Однофакторный дисперсионный анализ.

oneway educ by race.

** С выводом описательной статистики, тестом на равенство дисперсий в группах,
** графическим отображением средних в группах.

oneway educ by race
	/statistics=descriptives homogeneity
 /plot=means.

** То же самое с помощью команды Summarize.

summarize educ by race
	/statistics=anova.

** С помощью команды unianova


unianova educ by race
 /print = descriptive parameter
	/plot = profile(race).

* С помощью команды glm.

glm educ by race
	/print=parameter
	/contrast (race)=simple(1).

** Задание. Проведите дисперсионный анализ разницы средних между расововыми группами
** по переменной inc.

*** Двухфакторный дисперсионный анализ.

** Данные: Лейнхардта и Вассермана о детской смертности в странах мира.
** Источник: http://socserv.socsci.mcmaster.ca/jfox/Books/Applied-Regression-2E/datasets/index.html

FILE HANDLE leinhardt name = 'D:\hse\courses2011\introdatanal\lectures\lecture9\complab\leinhardt.sav'.
GET FILE = leinhardt.

** Полная модель с эффектами взаимодействия.

unianova income by region oil.

** Модель без эффектов взаимодействия.

unianova income by region oil
 /print = descriptive parameter
	/design=region  oil.

** Добавляем график со средними.

unianova income by region oil
 /print = descriptive parameter
	/design=region  oil
	/plot = profile(region*oil).

** Модель с эффектами взаимодействия и графиком.

unianova income by region oil
 /print = descriptive parameter
	/design=region*oil 
	/plot = profile(region*oil).

** или

unianova income by region oil
 /print = descriptive parameter
	/design=region oil region*oil 
	/plot = profile(region*oil).

** То же самое можно сделать с помощью команды glm.

glm income by region oil
	/print=parameter
	/design = region oil.

glm income by region oil
	/print=parameter
	/design = region oil region*oil
	/plot = profile(region*oil).

* Задание. Проведите двухфакторный дисперсионный анализ по переменной infant.




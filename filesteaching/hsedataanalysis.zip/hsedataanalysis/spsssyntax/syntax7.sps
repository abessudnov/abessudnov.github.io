﻿** Анализ социологических данных --1. НИУ ВШЭ, ф-т социологии, А.Р.Бессуднов
** 30 апреля 2012 г.

** 1. Логистическая регрессия: предсказанные вероятности и визуализация эффектов.


FILE HANDLE ess10log name = 'D:\hse\courses2011\introdatanal\lectures\lecture6\complab\ess2010log.sav'.
GET FILE = ess10log.

AUTORECODE VARIABLES=cntry /INTO cntry_num.
freq var=cntry_num.
recode cntry_num (5 10 11 16 18 =1) (else=0) into cntrdum.
** Отобраны Германия, Франция, Великобритания, Польша, Россия.
recode cntry_num (18 =1) (else=0) into rus.
** Отобрана Россия.
exe.

freq var=plccont.
recode plccont (2=0) (1=1) (else=sysmis) into contact.
exe.
freq var=contact.

recode gndr (1=1) (2=0) (else=sysmis) into male.

recode edlvdru (1 thru 3=1) (4=2) (5 6=3) (7=4) (8 thru 11=5) (else=sysmis) into edrus.
exe.

freq var=edlvdru.

filter by rus.

logistic regression contact with agea  male edrus
	/categorical=edrus.

** ln(p/(1-p))=-0.45-0.02*age+0.59*male-0.37*obschee srednee-0.03*polnoe srednee-0.08*PTU-0.18*tekhnikum

** p=exp(a)/(1+exp(a))

** Для того, чтобы вычислить вероятности, необходимо задать значения переменных.
** Например, возраст = 20, 40, 60 лет, пол = мужской, женский, образование = общее среднее, высшее.
** Это дает 12 комбинаций.

** Создадим новые переменные nage, nsex, nedu.

compute probcont=exp(-0.45-0.02*nage+0.59*nsex-0.37*nedu) / (1+exp(-0.45-0.02*nage+0.59*nsex-0.37*nedu)).
exe.

** Предсказанные вероятности содержатся в переменной probcont.

*** Похожей процедурой мы можем воспользоваться для создания графика с предсказанными вероятностями.
*** График имеет смысл только для интервальных переменных, в остальных случаях лучше представлять результаты
** в виде таблицы.

** Создадим в новой базе данных переменную для возраста agegraph со значениями от 20 до 70.
** Необходимо задать значения других переменных в модели на определенном уровне.
** Например: женщины, с высшим образованием.
** Создаем переменную с вероятностями.

compute probcontage=exp(-0.45-0.02*agegraph) / (1+ exp(-0.45-0.02*agegraph)).
exe.

graph /line(simple) = value(probcontage) by agegraph.

*********************************************************************************************************************************************************

*** 2. Мультиномиальная логистическая регрессия.

** Предвыборный опрос Фонда Общественное Мнение (сентябрь 2011 г.).

FILE HANDLE fomparties name = 'D:\hse\courses2011\introdatanal\lectures\lecture7\complab\parties2011.sav'.
GET FILE = fomparties.

freq var=Q_голоБД.

recode Q_голоБД (1=1) (2=2) (3=3) (4=4) (else=sysmis) into party.
recode Q_пол (1=1) (2=0) into male.
compute age=Q_возраст.
freq var=Q_образ.
recode Q_образ (1=1) (2=2) (3 4=3) (5 6 7=4) (8=sysmis) into educ.
exe.

freq var=party.
freq var=male.
freq var=educ.

nomreg party (base=4) by educ male with age
 /print = lrt cps mfi parameter summary.

** Сохраняя переменные с предсказанными вероятностями.

nomreg party (base=4) by educ male with age
 /print = lrt cps mfi parameter summary
	/save estprob(party).

** Таблица с предсказанными вероятностями для определенных значений предикторов.

** p(SpRo) = exp(Spro)  / (1+ exp(Spro) +exp(KPRF) + exp(LDPR))
** p(LDPR) = exp(LDPR)  / (1+ exp(Spro) +exp(KPRF) + exp(LDPR))
** p(KPRF) = exp(KPRF)  / (1+ exp(Spro) +exp(KPRF) + exp(LDPR))
** p(EdRo) = 1 / (1+ exp(Spro) +exp(KPRF) + exp(LDPR))

** Мужчины и женщины; 20, 40 и 60 лет, с высшим образованием.

** Создадим в базе данных переменные nage и nsex.

** p(SpRo)= exp(-2.758+0.017*nage-0.065*nsex) / (1 + exp(-2.758+0.017*nage-0.065*nsex) + exp(-0.458-0.009*nage-1.275*nsex) + exp(-2.638+0.046*nage-0.908*nsex))
** p(LDPR)= exp(-0.458-0.009*nage-1.275*nsex) / (1 + exp(-2.758+0.017*nage-0.065*nsex) + exp(-0.458-0.009*nage-1.275*nsex) + exp(-2.638+0.046*nage-0.908*nsex))
** p(KPRF)= exp(-2.638+0.046*nage-0.908*nsex) / (1 + exp(-2.758+0.017*nage-0.065*nsex) + exp(-0.458-0.009*nage-1.275*nsex) + exp(-2.638+0.046*nage-0.908*nsex))
** p(EdRo) = 1 / (1 + exp(-2.758+0.017*nage-0.065*nsex) + exp(-0.458-0.009*nage-1.275*nsex) + exp(-2.638+0.046*nage-0.908*nsex))


compute SpRo= exp(-2.758+0.017*nage-0.065*nsex) / (1 + exp(-2.758+0.017*nage-0.065*nsex) + exp(-0.458-0.009*nage-1.275*nsex) + exp(-2.638+0.046*nage-0.908*nsex)).
compute LDPR= exp(-0.458-0.009*nage-1.275*nsex) / (1 + exp(-2.758+0.017*nage-0.065*nsex) + exp(-0.458-0.009*nage-1.275*nsex) + exp(-2.638+0.046*nage-0.908*nsex)).
compute KPRF= exp(-2.638+0.046*nage-0.908*nsex) / (1 + exp(-2.758+0.017*nage-0.065*nsex) + exp(-0.458-0.009*nage-1.275*nsex) + exp(-2.638+0.046*nage-0.908*nsex)).
compute EdRo = 1 / (1 + exp(-2.758+0.017*nage-0.065*nsex) + exp(-0.458-0.009*nage-1.275*nsex) + exp(-2.638+0.046*nage-0.908*nsex)).
exe.

** Задание. Оцените модель зависимости рода занятий (Q_родЗан) от пола, возраста, образования. Род занятий перекодируйте в переменную с пятью значениями:
** 1) бизнесмен, руководитель, специалист; 2) служащий, технический исполнитель; 3) рабочий; 4) пенсионер; 5) другое.
** Оцените вероятности попадания в каждую категорию для: мужчин и женщин; 30 и 50 лет; со средним и высшим образованием.
** Проинтерпретируйте результаты.

****************************** 3. Порядковая регрессия.

FILE HANDLE isspru name = 'D:\hse\courses2011\introdatanal\lectures\lecture7\complab\issp2003ru.sav'.
GET FILE = isspru.

freq var v50.
freq var age.
freq var sex.
freq var urbrural.

recode sex (1=1) (2=0) into male.
exe.

plum v50 with age by male urbrural degree
/link = logit 
/print = parameter summary tparallel
/save estprob.

** Предсказанные вероятности: мужчины и женщины, 30 и 50 лет.
** Новые переменные: nage, nsex


compute eta_0=-0.014*nage+0.158*nsex.
compute eta_1=-1.545-eta_0.
compute eta_2=-0.182-eta_0.
compute eta_3=0.676-eta_0.
compute eta_4=1.966-eta_0.

compute g_1 = 1/(1+exp(-eta_1)) .
compute g_2 = 1/(1+exp(-eta_2)) .
compute g_3 = 1/(1+exp(-eta_3)) .
compute g_4 = 1/(1+exp(-eta_4)) .

compute p_1 = g_1 .
compute p_2 = g_2 - g_1 .
compute p_3 = g_3 - g_2 .
compute p_4 = g_4 - g_3 .
compute p_5 = 1 - g_4.
execute .

** Задание. Оцените порядковую логистическую регрессию для зависимости переменной v48 от возраста, пола, образования и места жительства.
** Вычислите предсказанные вероятности для мужчин и женщин, 20 и 60 лет, с высшим и средним образованием, живущих в городе и на селе.
















﻿* Тема 1. Основы работы в SPSS.

* Как устроен SPSS: окна данных (закладки данных и переменных), окно синтаксиса, окно результатов
	 (output). Файлы данных, синтаксиса и результатов сохраняются отдельно.

* Работа в SPSS с помощью меню и с помощью синтаксиса. Преимущества синтаксиса (документация
проекта, возможность редактировать код и быстро выполнять повторяющиеся задачи, скорость,
возможность сотрудничества в рамках одного проекта, возможность репликации результатов).

* Синтаксис SPSS: основы. Окно синтаксиса. Интерактивный режим ввода команд и batch-mode.
* Not case-sensitive, команда заканчивается точкой, некоторые команды, меняющие данные,
должны заканчиваться командой "execute.", опции вводятся через /.

* Комментарии: начинаются со звездочки, заканчиваются точкой.
/* Или заключаются между этими символами  */

* Доступные справочные ресурсы.
* 1) SPSS Statistics 17.0 Command Syntax Reference.
* 2) R.Levesque. "SPSS Programming and Data Management".
* см также Raynald's SPSS Tools - http://www.spsstools.net/.
* 3) Bolslaugh S. "An Intermediate Guide to SPSS Programming. Using Syntax for Data Management".
* 4) обучающие видеоролики доступны на  http://www-01.ibm.com/software/analytics/spss/academic/students/tutorials.html .
* 5) Большое количество ресурсов доступно на http://www.ats.ucla.edu/stat/seminars/ .

* Команда SHOW ALL показывает текущие настройки.

SHOW ALL.

* Получение справки: 1) меню Help, 2) SPSS Statistics Base 17.0 User Guide.

* Опция. позволяющая выводить тест команд в окне результатов.

set printback = on.

* Формат данных в SPSS: прямоугольная таблица, переменные и наблюдения.
* Важность управления данными в статистическом анализе.

* Ввод данных. 

* 1) Ввод через окно редактора данных и переменных.

* 2) Ввод через окно синтаксиса (используется редко).

DATA LIST FREE / id female iq class.
BEGIN DATA
1 1 105 1
2 0 98 1
3 1 100 2
4 0 102 2
END DATA.
LIST VAR = ALL.

* 3) Чтение готовых файлов.

FILE HANDLE ess name = 'D:\hse\courses2011\introdatanal\lectures\lecture 1\seminar1\class1ess.sav'.
GET FILE = ess.

* SPSS умеет читать текстовые файлы с данными, файлы Excel, Stata и других форматов.

* Меню: File -> New, File -> Open.

* Описание окон данных и переменных.
* Типы переменных: numeric и string.
* Типы шкал: scale, nominal, ordinal.

* Переменные, метки переменных, метки значений переменных. Отсутствующие (пропущенные)
значения.

* Описательная статистика.

* Меню:Analyze -> Descriptive statistics -> Frequencies.
* Опция Paste.

* Синтаксис.

FREQUENCIES VARIABLES=tvtot.

* Наиболее важные опции.

FREQUENCIES VARIABLES=tvtot
	/ STATISTICS = all.

* Опции STATISTICS = MEAN MEDIAN VARIANCE etc.

FREQUENCIES VARIABLES=tvtot
	/ barchart.

FREQUENCIES VARIABLES=tvtot
	/ PIECHART.

FREQUENCIES VARIABLES=tvtot
	/ hist.

* Несколько переменных сразу.

freq var = happy health rlgdgr.

* Отдельная таблица со статистическими параметрами для каждой переменной.

freq var = happy health rlgdgr
	/ order=variable.


*** Задание 1 (5 мин.). Самостоятельно примените команду FREQUENCIES к переменной stflife.
*** Используйте разные подкомманды.

** Сохранение данных.
** Меню: File -> Save, File -> Save as. Данные, синтаксис и результаты сохраняются отдельно в
** отдельных файлах.

SAVE OUTFILE =  'D:\hse\courses2011\introdatanal\lectures\lecture 1\seminar1\class1ess_2.sav'.

** Опции KEEP и DROP позволяют удалять ненужные переменные.

SAVE OUTFILE =  'D:\hse\courses2011\introdatanal\lectures\lecture 1\seminar1\class1ess_3.sav'
					/DROP=cntry.

** Можно также переименовывать (RENAME) и сортировать (KEEP) переменные.

** SAVE TRANSLATE позволяет сохранять данные в других форматах.

SAVE TRANSLATE OUTFILE= 'D:\hse\courses2011\introdatanal\lectures\lecture 1\seminar1\class1.dta'
	/TYPE=STATA /MISSING=RECODE.

** Опция /MISSING=RECODE перекодирует пропущенные значения, определенные пользователем,
* в системные пропущенные значения (иначе они воспринимаются Stata как обычные значения).

******* Перекодирование и создание новых переменных.
* Меню: Transform -> Recode into same variables, Transform -> Recode into different variables.
* (Почти) всегда перекодируйте переменные в новые переменные.

freq var = tvtot.

** Чтобы вывести как метки значений переменных, так и сами значения переменных.

SET TNUMBERS = BOTH.

freq var = tvtot.

* Я хочу перекодировать эту переменную в переменную с тремя значениями: вообще не смотрят ТВ,
* смотрят в среднем меньше двух часов в день, смотрят больше двух часов в день.

RECODE tvtot (0=1) (1 thru 4=2) (5 6 7=3) (else=sysmis) INTO tvtot3.
VARIABLE LABELS  tvtot3 'TV watching -- 3 categories'.
VALUE LABELS tvtot3 
		1 'no time at all'
		2 '<2 hrs'
		3 '>2 hrs'.
EXECUTE.
freq var=tvtot3.

* Использование EXECUTE.

* Меняем формат переменной (убирая знаки после запятой).
FORMATS tvtot3 (F2).
freq var=tvtot3.

* Синтаксис команды RECODE позволяет перекодировать несколько переменных одновременно.

* Перекодирование интервальной переменной.

freq var=agea.
recode agea (lo thru 25 =1) (26 thru 45=2) (46 thru hi=3) (else=sysmis) into agecat.
variable labels agecat 'Age - categories'.
value labels agecat
	1 'young'
	2 'middle-aged'
	3 'mature'.
execute.
FORMATS agecat (F2).
freq var=agecat.

* Команда RECODE позволяет также менять формат переменных с числового на символьный и наоборот.

** Во сколько категорий перекодировать переменные?

** Задание 2. а) Создайте переменную male, где 1 означает мужчин, а 0 - женщин.
* б) Перекодируйте переменную grspaya (заработная плата в евро) в переменную с четырьмя 
* категориями, содержащими примерно равное число респондентов.

**** Команда COMPUTE.
* Используется для создания новых переменных. Должно сопровождаться EXECUTE.
* Также может использоваться для изменения существующих переменных, к чему следует
* относиться с осторожностью.

* Меню: Transform -> Compute variable.

COMPUTE age2=agea*agea.
EXE.

COMPUTE logpay=lg10(grspaya).
exe.

** Логарифмическая функция не определена в точке 0. Обычным решением является добавить 0.5.

COMPUTE logpay2=lg10(grspaya+0.5).
exe.

COMPUTE newvar=0.
EXECUTE .

compute newvar2=0.

** Список допустимых функций довольно широк. Наиболее распространенные: +, -, *, /, 
* sqrt, lg10, ln, exp, rnd, trunc.См. оконный интерфейс.

** Создание символьных переменных.

STRING reg (A5).
compute reg=strunc(region, 3).
exe.

* strunc в данном случае сокращает переменную до первых трех символов. Существует
* большое количество функций для символьных переменных.

** Удаление переменных.
* Через окно данных.

DELETE VARIABLES newvar newvar2.

** Перекодирование символьных (string) переменных в численные (numeric).

freq var=cntry.
AUTORECODE VARIABLES=cntry /INTO cntry_num.
freq var=cntry_num.

** Более тонкое управление перекодированием возможно с помощью команды RECODE
** и ее опции convert, которые мы не будем рассматривать.

** Сортировка переменных по имени

SORT VARIABLES by name.

** Возможный другие опции - сортировка по типу и т.д.
** Автоматически сохраняет базу данных -- никогда не используйте эту команду, если вы этого не хотите!


***  Команда IF. Условные операторы в SPSS.

compute payrus=grspaya.
if cntry NE "RU" payrus=$sysmis.
exe.
freq var=payrus.

** NE означает "not equal".
** Возможные операторы: >, <,  =, <=, >=, <>. У каждого из операторов есть буквенный аналог:
** GT, LT, EQ, LE, GE, NE.
** Также могут использоваться AND (&), OR (|) и NOT.

compute payrus_cat=$sysmis.
if payrus>0 & payrus<200 payrus_cat=1.
if payrus>=200 & payrus<300 payrus_cat=2.
if payrus>=300 & payrus<500 payrus_cat=3.
if payrus>=500 payrus_cat=4.
variable labels payrus_cat "Gross pay Russia in euro categorical ".
value labels payrus_cat
	1 '<200'
	2 '200-300'
	3 '300-500'
	4	'>500'.
exe.
freq var=payrus_cat.

** Команда DO IF.
** Та же самая задача.

DO IF cntry='RU'.
recode grspaya (MISSING=SYSMIS) (lo thru 199=1) (200 thru 299=2) (300 thru 499=3) (500 thru hi=4) into payrus_cat2.
variable labels payrus_cat2 "Gross pay Russia in euro categorical - another version".
value labels payrus_cat2
	1 '<200'
	2 '200-300'
	3 '300-500'
	4	'>500'.
END IF.
EXECUTE .
freq var=payrus_cat2.

list payrus payrus_cat payrus_cat2
	/cases from 35800 to 35820.

***** Задание 3. 

* 3.1. Создайте переменную со следующими значениями: 1 - мужчины до 30 лет, 2 - женщины 
* до 30 лет, 3 - мужчины от 30 до 50 лет, 4 - женщины от 30 до 50 лет, 5 - мужчины старше 50 лет,
* 6 - женщины старше 50 лет. Создайте метки переменной и метки значений переменной.

* 3.2. Создайте символьную (string) переменную со следующими категориями: скандинавские страны,
** страны южной Европы (Италия, Португалия), остальные западноевропейские страны,
** восточноевропейские страны, другие страны. Перекодируйте эту переменную в численную.
** Создайте дихотомическую переменную для субъективной оценки здоровья (health, 
** "very bad" или "bad" vs. другие варианты, исключая пропущенные значение), только для 
** скандинавских стран. Для остальных стран значения этой переменной должны быть приравнены
** к системным пропущенным (sysmis).

*******************************************************************************************************************

** Сортировка наблюдений по значению переменных.
** Команда SORT CASES

SORT CASES BY happy.

SORT CASES BY happy (A) health (D).

* A - восходящий порядок, D - нисходящий порядок.

**********************

** Команда SELECT IF.
* Эта команда отбирает подвыборку из данных в соответствии с определенным условием.
** Неотобранные наблюдения удаляются. Используйте эту команду с осторожностью.

** Удалить женщин из выборки.

SELECT IF gndr=1. 
exe.

get file=ess.

** Временно удалить наблюдения.

TEMPORARY .
SELECT IF gndr=1.
freq var=tvtot.
freq var=tvtot.

* Первая команда freq выдает распределение только для мужчин, вторая -- для всей выборки.
* В случае использования temporary, команда select if действует только для следующей команды.

** Команда FILTER.
** Не удаляет наблюдения.
** Для использования FILTER необходимо создать дихотомическую переменную, по которой осуществляется фильтрация.
** Наблюдения со значением переменной равным нулю не принимаются во внимание в дальнейших процедурах, но не удаляются из базы данных.

freq var=gndr.
RECODE gndr (1=1) (2=0) (missing=sysmis) into male.
freq var=male.
filter by male.
freq var=tvtot.
filter off.

** Команда SPLIT FILE.
** Делит наблюдения на группы, после чего другие команды выдают статистику отдельно по группам.

SORT CASES by gndr.
SPLIT FILE by gndr.
freq var=tvtot.
SPLIT FILE OFF.
** Отключает SPLIT FILE.

*** Взвешивание базы данных. Команда WEIGHT.
** Может использоваться для взвешивания агрегированных баз данных по количеству случаев в отдельных категориях.
** Эта команда используется для частотных весов (frequency weights)), для вероятностных весов (probability weights) ее использование не вполне корректно.
** SPSS автоматически округляет веса до ближайшего целого.
** Вероятностные веса поддеживаются в продукте SPSS Complex Samples.
** Следующий код служит только для примера (поскольку мы не можем применять weight к вероятнностным весам).

temporary.
select if cntry='RU'.
freq var=gndr.

weight by dweight.
temporary.
select if cntry='RU'.
freq var=gndr.
weight off.

**************************************************************************

** Пропущенные значения (missing values) в SPSS.
** Пропущенные значения не используются в статистическом анализе.
** SPSS различает системные пропущенные значения (SYSMIS) и пропущенные значения,
** заданные пользователем. Пропущенные значения задаются с помощью команды
** MISSING VALUES.

freq var=marsts.
missing values marsts ().
** Удаляет заданные пользователем пропущенные значения.
freq var=marsts.
missing values marsts (66 thru 99).
freq var=marsts.

*** Переменные в формате даты и времени.
*** Для этих переменных в SPSS используется особый формат.
*** В основном необходим для работы с временными рядами.
** См. DATE -- подробнее мы сейчас это разбирать не будем.

*** Создание случайных переменных с заданным типом распределения.

* Однородное распределение.
compute rand_uni=uniform(100).
exe.
freq var=rand_uni
			/ format=notable
			/ statistics=all
		/ hist=NORMAL.
** Опция Format в данном случае подавляет вывод таблицы со значениями переменной (их слишком много),
** опция hist выводит гистограмму с наложенной кривой нормального распределения.

* Нормальное распределение.
compute rand_norm=rv.norm(50,10).
* Средняя = 50, стандартное отклонение = 10.
exe.
freq var=rand_norm
			/ format=notable
			/ statistics=all
		/ hist=NORMAL.

* Для других распределений см. SPSS  Command Syntax Manual, гл. Probability Density Functions.


*** Экспорт результатов анализа (output). SPSS позволяет экспортировать результаты
*** в форматах Word, Excel, etc.
*** Плюсы и минусы этой опции.
*** Команда OUTPUT EXPORT.

*** Задание 4. Создайте дихотомическую переменную, которая принимает значение 1 для тех
** респондентов, для которых в базе присутствует информация об их семейном положении и 
** роде деятельности (и 0 для всех остальных). Отфильтруйте данные по этой переменной.


*******************************************************************************************************************
***** Операции с файлами в SPSS.
** Очень важны для управления данными.

*** Агрегация данных. Создание базы данных со средними значениями для групп.

** Допустим, мы хотим создать базу данных со средними значениями возраста и дохода по странам.
** Команда AGGREGATE.
** Меню Data -> Aggregate.

** Сохраняйте данные перед тем, как агрегировать их!

AGGREGATE OUTFILE='D:\hse\courses2011\introdatanal\lectures\lecture 1\seminar1\class1ess_means.sav'
	/break cntry
 /meanage=mean(agea)
 /meanpay=mean(grspaya).

get file='D:\hse\courses2011\introdatanal\lectures\lecture 1\seminar1\class1ess_means.sav'.
** Изучите получившиеся результаты.

** break может содержать несколько переменных.

** В следующем примере мы хотим вычислить средний возраст для стран и присоединить эту переменную к имеющейся базе данных.

get file=ess.
AGGREGATE OUTFILE= * mode=addvariables
	/break cntry
 /meanage=mean(agea).

*************************************************************************

*** Добавление файла с наблюдениями к существующему файлу.

** Разделим наш файл на два файла: для мужчин и для женщин.

get file=ess.
freq var=gndr.
select if gndr=1.
exe.
save outfile= 'D:\hse\courses2011\introdatanal\lectures\lecture 1\seminar1\class1ess_men'.
get file=ess.
select if gndr=2.
exe.
save outfile= 'D:\hse\courses2011\introdatanal\lectures\lecture 1\seminar1\class1ess_women'.

get file= 'D:\hse\courses2011\introdatanal\lectures\lecture 1\seminar1\class1ess_men'.

* Добавим к файлу с наблюдениями для мужчин файл с наблюдениями для женщин.

ADD FILES FILE='D:\hse\courses2011\introdatanal\lectures\lecture 1\seminar1\class1ess_men'
			/FILE='D:\hse\courses2011\introdatanal\lectures\lecture 1\seminar1\class1ess_women'.
exe.

*************************************************************************************************************

** Объединение файлов, содержащих одни и те же наблюдения, но разные переменные.
** Для этого необходимо наличие id переменной.
** Используется команда MATCH FILES.

get file=ess.

** Создадим переменную с уникальным id (idno не является уникальным).

compute id=$casenum.
exe.

** Сохраним файл с переменными id, страна, пол, возраст.

MATCH FILES FILES = *
		/KEEP = id cntry gndr 	agea.
exe.
sort cases by id.
save outfile= 'D:\hse\courses2011\introdatanal\lectures\lecture 1\seminar1\class1ess_match1'.

** Сохраним в другом файле переменные id, семейное положение, образование (используя другой способ).

get file=ess.
compute id=$casenum.
exe.
save outfile='D:\hse\courses2011\introdatanal\lectures\lecture 1\seminar1\class1ess_match2'
	/keep=id marsts eisced.
get file='D:\hse\courses2011\introdatanal\lectures\lecture 1\seminar1\class1ess_match2'.
sort cases by id.
save outfile='D:\hse\courses2011\introdatanal\lectures\lecture 1\seminar1\class1ess_match2'.

** Теперь объединим оба файла.

MATCH FILES file='D:\hse\courses2011\introdatanal\lectures\lecture 1\seminar1\class1ess_match1'
				/file='D:\hse\courses2011\introdatanal\lectures\lecture 1\seminar1\class1ess_match2'
				/by=id.
exe.

**** Для обновления данных используется команда UPDATE, но она менее важна и реже применяется.

****************************************************************************************************************

**** Изменение структуры данных (reshaping). Перевод из "длинного" в "широкий" формат и наоборот.
** Применяется для работы с панельными данными и другими данными с иерархической структурой.

** Введем данные для примера.

DATA LIST FREE / id female iq year.
BEGIN DATA
1 1 105 2000
1	1	102	2005
1	1	108	2010
2 0 98 2000
2	0	98	2005
2	0	105	2010
3 1 100 2000
3	1	94	2005
3	1	92	2010
END DATA.
FORMATS all (F4).
LIST VAR = ALL.

** Данные введены в "длинном" формате (на каждое наблюдение за отдельный год приходится отдельная строчка).
** Мы хотим их перевести в "широкий" формат: одна строчка на каждого респондента, данные за разные годы представлены в виде переменных.

CASESTOVARS
				/ID = id
			/INDEX=year.
LIST VAR = ALL.

** Обратно в "длинный" формат:

VARSTOCASES
		/ MAKE iq FROM iq.2000 to iq.2010
		/ INDEX=ivar(iq).
LIST VAR = ALL.

** Год представлен в качестве текстовой переменной. Мы хотим представить его в виде численной переменной .

string year (A4).
compute year = substr(ivar,4).
** Выделяет год из текстовой переменной.
compute year_num=number(year).
** Переводит год в численный формат.
exe.
list var=all.

***************************************************************************************************************

**** Задание 5. 
*** 5.1. Создайте файл с данными, который содержал бы переменные с процентом людей с высшим образованием в разных страных
*** (среди всех респондентов старше 25 лет, отдельно для мужчин и женщин старше 25 лет, отдельно по возрастным группам 26-35, 36-45 и старше 45 лет).

*** 5.2. Удалите из базы данных все наблюдения, кроме первых 10 наблюдений для каждой страны. Удалите все переменные, кроме переменных с id, страной,
*** и возрастом. Переведите данные из "длинного" в "широкий" формат.

** Подсказка: пронумеруйте наблюдения внутри стран, используя функцию lag, и отберите только наблюдения с id <11. См. код ниже.

get file=ess.
sort cases by cntry idno.
** Создаем переменную, равную 1.
compute id=1.
* Если значение переменной cntry равно значению той же переменной в предыдущей строке, берем значение переменной id из предыдущей строки и добавляем 1.
if cntry=lag(cntry) id = lag(id)+1.
exe.

﻿** Практические занятия 10-12. Трансформации переменных, нелинейные связи, эффекты взаимодействия.
** Анализ данных -1, НИУ ВШЭ, ф-т социологии, А.Р.Бессуднов, 2012

FILE HANDLE rlms name = 'D:\hse\courses2011\introdatanal\lectures\lecture4\seminar\rlms2009.sav'.
GET FILE = rlms.

** nj10 -- заработная плата за прошедший месяц.

means table=nj10 nj60.
examine var=nj10
	/plot=histogram.
freq var=nj10.

missing values nj10 (99999997 thru 99999999).
freq var=nj10.

graph
	/histogram=nj10.


*** Заработная плата и возраст.

freq var=nh6.
compute age=2009-nh6.
exe.

GRAPH
  /SCATTERPLOT(BIVAR)=age WITH nj10
  /MISSING=LISTWISE.

regression
	/dependent=nj10
		/method=enter age
	/save pred(pred1).

compute age2=age*age.
compute age3=age2*age.
exe.

regression
	/dependent=nj10
		/method=enter age age2
	/save pred(pred2).

regression
	/dependent=nj10
		/method=enter age age2 age3
	/save pred(pred3).

sort cases by age.

CURVEFIT
  /VARIABLES=nj10 WITH age
  /CONSTANT
  /MODEL=LINEAR QUADRATIC CUBIC 
  /PLOT FIT.

** Задание.
** 1. Постройте модель зависимости заработной платы от возраста отдельно для мужчин и женщин.
** Сравните результаты.

** Логарифмическое преобразование дохода/зарплаты в качестве независимой переменной.

freq var=nj62.
missing values nj62 (99999997 thru 99999999).
freq var=nj60.
missing values nj60 (99999997 thru 99999999).

* Исключаем из рассмотрения случаи с доходом равным 0.
compute inc=nj60.
exe.
missing values inc (0).
freq var=inc.

CURVEFIT
  /VARIABLES=nj62 WITH inc
  /CONSTANT
  /MODEL=LINEAR LOGARITHMIC QUADRATIC
  /PLOT FIT.

missing values inc (0 1846250).

CURVEFIT
  /VARIABLES=nj62 WITH inc
  /CONSTANT
  /MODEL=LINEAR LOGARITHMIC QUADRATIC
  /PLOT FIT.

compute loginctot=ln(inc).
exe.
GRAPH
  /HISTOGRAM=loginctot.

CURVEFIT
  /VARIABLES=nj62 WITH loginctot
  /CONSTANT
  /MODEL=LINEAR LOGARITHMIC QUADRATIC
  /PLOT FIT.


** Логарифмическое преобразование дохода/зарплаты в качестве зависимой переменной.

freq var=nj10.
GRAPH
  /HISTOGRAM=nj10.
compute loginc=ln(nj10).
exe.
GRAPH
  /HISTOGRAM=loginc.

** Задание 2. Постройте модель зависимости логарифмы зарплаты от возраста, пола и образования 
** (модель Минцера).

*********************************************************************

** Эффекты взаимодействия между переменными.
** Взаимодействие категориальной и интервальной переменных.

freq var=nj62.
regression
	/dependent=nj62
		/method=enter age age2 nh5
		/save pred(predage).

graph
/scatterplot(bivar)=age with predage by nh5.

compute agesex=age*nh5.
exe.

regression
	/dependent=nj62
		/method=enter age nh5 agesex
		/save pred(predage2).

graph
/scatterplot(bivar)=age with predage2 by nh5.

*** Взаимодействие интервальной переменной и категориальной переменной с большим, чем 2,
*** количеством значений. Возраст и образование.

freq var=n_diplom.

if n_diplom NE missing(n_diplom) educ1=0.
if n_diplom = 1 educ1 = 1.
if n_diplom NE missing(n_diplom) educ2=0.
if n_diplom = 2 educ2 = 1.
if n_diplom NE missing(n_diplom) educ3=0.
if n_diplom = 3 educ3 = 1.
if n_diplom NE missing(n_diplom) educ4=0.
if n_diplom = 4 educ4 = 1.
if n_diplom NE missing(n_diplom) educ5=0.
if n_diplom = 5 educ5 = 1.
exe.

** Без эффектов взаимодействия.

regression
	/dependent=nj62
		/method=enter age educ1 educ2 educ3 educ4 educ5
		/save pred(prededuc).

graph
/scatterplot(bivar)=age with prededuc by n_diplom.

** С эффектами взаимодействия.

compute ageduc1=age*educ1.
compute ageduc2=age*educ2.
compute ageduc3=age*educ3.
compute ageduc4=age*educ4.
compute ageduc5=age*educ5.
exe.

regression
	/dependent=nj62
		/method=enter age educ1 educ2 educ3 educ4 educ5 ageduc1 ageduc2 ageduc3 ageduc4 ageduc5
		/save pred(prededuc2).

graph
/scatterplot(bivar)=age with prededuc2 by n_diplom.

*** Взаимодействие двух интервальных переменных.

regression
	/dependent=nj62
		/method=enter inc.

regression
	/dependent=nj62
		/method=enter loginc.

regression
	/dependent=nj62
		/method=enter age loginc
 	/save pred(predinc).

compute age2040=$sysmis.
if age=20 age2040=1.
if age=40 age2040=2.
exe.
freq var=age2040.

graph
/scatterplot(bivar)=loginc with predinc by age2040.

*** Эффект взаимодействия.

compute ageinc=age*loginc.
exe.

regression
	/dependent=nj62
		/method=enter age loginc ageinc
 	/save pred(predinc2).

graph
/scatterplot(bivar)=loginc with predinc2 by age2040.

** Взаимодействие двух категориальных переменных.
** Образование и пол.

freq var=nh5.
recode nh5 (1=1) (2=0) into male.
exe.

compute maleduc1=male*educ1.
compute maleduc2=male*educ2.
compute maleduc3=male*educ3.
compute maleduc4=male*educ4.
compute maleduc5=male*educ5.
exe.

regression
	/dependent=nj62
		/method=enter male educ1 educ2 educ3 educ4 educ5 maleduc1 maleduc2 maleduc3 maleduc4 maleduc5.

***********************************8

** Задание 3. Постройте регрессионную модель зависимости дохода от пола, возраста, образования.
** Проверьте, значимы ли эффекты взаимодействия. Постройте графики с результатами моделирования.







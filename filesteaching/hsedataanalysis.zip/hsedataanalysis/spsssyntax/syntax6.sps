﻿** Анализ социологических данных - 1, НИУ ВШЭ, социологический ф-т, А.Р.Бессуднов
** Практические занятия 14-16. Регрессионные модели для дихотомических зависимых переменных.

** Логистическая регрессия.

FILE HANDLE ess10log name = 'D:\hse\courses2011\introdatanal\lectures\lecture6\complab\ess2010log.sav'.
GET FILE = ess10log.

AUTORECODE VARIABLES=cntry /INTO cntry_num.
freq var=cntry_num.
recode cntry_num (5 10 11 16 18 =1) (else=0) into cntrdum.
** Отобраны Германия, Франция, Великобритания, Польша, Россия.
recode cntry_num (18 =1) (else=0) into rus.
** Отобрана Россия.
exe.


** Зависимость вероятности контакта с полицией от вораста.

freq var=plccont.
recode plccont (2=0) (1=1) (else=sysmis) into contact.
exe.
freq var=contact.
filter by rus.

logistic regression contact with agea.

** Расчет предсказанных моделью вероятностей.
** p = exp(a+bx)/(1+exp(a+bx))

logistic regression contact with agea
	/save pred(pred).

** logit(p)= - 0.17 - 0.022*age

** Линейная модель вероятности.

regression
	/dependent=contact
		/method=enter agea
		/save pred(pred2).

** p = 0.418-0.004*age

** График с предсказанными вероятностями.
** Создаем новую базу данных с переменной age со значениями от 21 до 70.

input program.
  loop #i = 1 to 50 by 1.
  compute age = #i+20.
  end case.
end loop.
end file.
end input program.
execute.

* Для каждого значения age рассчитываем предсказанную вероятность по формуле.

compute prob = exp(-0.17-0.022*age) / (1+ exp(-0.17-0.022*age)).
exe.

** Линейная модель вероятности.

compute prob2 = 0.418-0.004*age.
exe.

graph /line(simple) = value(prob) by age.
graph /line(simple) = value(prob2) by age.


get file=ess10log.
filter by rus.
compute age2=(agea*agea)/100.
exe.

** Четыре модели: линейная и логистическая. с квадратичным членом и без.

logistic regression contact with agea
	/save pred(pred).

regression
	/dependent=contact
		/method=enter agea
		/save pred(pred2).

logistic regression contact with agea age2
		/save pred(pred3).

* logit(p)=-1.608+0.051age-0.08*(age2/100)

regression
	/dependent=contact
		/method=enter agea age2
		/save pred(pred4).

* p=0.238+0.005age-0.009*(age2/100)

** График с предсказанными вероятностями.

input program.
  loop #i = 1 to 50 by 1.
  compute age = #i+20.
  end case.
end loop.
end file.
end input program.
execute.

* Логит.
compute prob1 = exp(-0.17-0.022*age) / (1+ exp(-0.17-0.022*age)).
** Линейная модель.
compute prob2 = 0.418-0.004*age.
* Логит с квадратичным членом.
compute prob3 = exp(-1.608+0.051*age-0.08*(age*age/100)) / (1+  exp(-1.608+0.051*age-0.08*(age*age/100))).
** Линейная модель с квадратичным членом.
compute prob4=0.238+0.005*age-0.009*(age*age/100).
exe.

graph /line(simple) = value(prob1) by age.
graph /line(simple) = value(prob2) by age.
graph /line(simple) = value(prob3) by age.
graph /line(simple) = value(prob4) by age.

*** Модель с несколькими предикторами.

get file=ess10log.

** Предикторы контакта с полицией в России: пол и возраст.

filter by rus.

freq var=gndr.

recode gndr (1=1) (2=0) (else=sysmis) into male.
exe.

logistic regression contact with agea age2 male
 /save pred (predmale).

** Эффект взаимодействия.

compute agemale=agea*male.
compute age2male=age2*male.
exe.

logistic regression contact with agea age2 male agemale age2male
 /save pred (predmale2).

logistic regression contact with agea age2 male agemale
 /save pred (predmale3).

** Эффекты взимодействия не значимы.

** Категориальные предикторы.

freq var=edlvdru.

recode edlvdru (1 thru 3=1) (4=2) (5 6=3) (7=4) (8 thru 11=5) (else=sysmis) into edrus.
exe.
freq var=edrus.


logistic regression contact with agea age2 male edrus
	/categorical=edrus.

** Задание 1. Рассчитайте регрессионную модель зависимости вероятности контакта с полицией в пяти странах: в Германии, Франции, Великобритании, Польше, России.
** Как различаются вероятности контакта с полицией по странам? Рассчитайте вероятность контакта с полицией мужчины 30 лет в пяти странах. Создайте графики зависимости
** вероятности контакта с полицией в пяти странах для мужчин. Добавьте в модель переменные доход и семейное положение. Значимы ли эти эффекты? Оцените эффекты
** действия между страной и другими переменными.


** Задание 2. Постройте модель логистической регрессии зависимости вероятности наличия человека, с которым респондент может обсуждать личные проблемы (inmdisc),
** от социально-демографический характеристик (пол, возраст, семейное положение, образование, доход) в нескольких странах. Проиллюстрируйте результаты графиками
** и предсказанными вероятностями.







﻿** 21 мая 2012 г. Логарифмически-линейные модели.
** Анализ данных -1 (А.Р.Бессуднов, ф-т социологии, второй курс)

** Данные о связи пола и веры в загробную жизнь
** Источник: A.Agresti, An Introduction to Categorical Data Analysis

FILE HANDLE aftlife name = 'D:\hse\courses2011\introdatanal\lectures\lecture8\complab\afterlife.sav'.
GET FILE = aftlife.

weight by freq.

crosstabs sex by afterlife
	/cells=count row column expected
	/statistics=chisq.


** Насыщенная модель.

genlog sex afterlife.

genlog sex afterlife
	/print=all.

** Модель независимости.

genlog sex afterlife
	/design sex afterlife
/print=all.

** Автоматический выбор модели.

hiloglinear sex(1,2) afterlife(1,2)
	/method=backward
/print=all
/design.



** Данные об употреблении алкоголя, сигарет и марихуаны
** Источник: A.Agresti, An Introduction to Categorical Data Analysis

FILE HANDLE acm name = 'D:\hse\courses2011\introdatanal\lectures\lecture8\complab\acm.sav'.
GET FILE = acm.

weight by freq.

** Модель независимости.

genlog a c m
	/design a c m
/print=all.

genlog a c m
	/design a m c a*c
/print=all
/plot=none.

genlog a c m
	/design a m c a*c a*m m*c
/print=all
/plot=none.

hiloglinear a(1,2) c(1,2) m(1,2)
	/method=backward
/print=all
/design.

** Данные о социальной мобильности в трех странах (Англия и Уэльс, Франция, Швеция)
** из работы Эриксона, Голдторпа и Портокареро (1982).

FILE HANDLE erikson name = 'D:\hse\courses2011\introdatanal\lectures\lecture8\complab\erikson.sav'.
GET FILE = erikson.

weight by count.

crosstabs origin by destination by country
	/cells=count row column expected
	/statistics=chisq.


genlog origin destination country
	/design origin destination country
/print=all
/plot=none.

hiloglinear origin(1,9) destination(1,9) country(1,3)
	/method=backward
/print=all
/design.

genlog origin destination country
	/design origin destination country origin*destination origin*country destination*country
/print=all
/plot=none.

*** Задание. Перекодируйте классовую схему в схему из трех категорий: 1) салариат (I,II),
2) промежуточные классы (III,IV,V), 3) рабочий класс (VI,VII) и проведите логлинейный анализ.


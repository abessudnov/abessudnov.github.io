﻿** Практические занятия 4-6. Описательная статистика. Графики.

FILE HANDLE ess name = 'D:\hse\courses2011\introdatanal\lectures\lecture2\seminar\class1ess.sav'.
GET FILE = ess.

*** Частотное распределение.

freq var = marsts.

** Таблицы сопряженности.

crosstabs tables=marsts by cntry.

freq var=cntry.
AUTORECODE VARIABLES=cntry /INTO cntry_num.
freq var=cntry_num.
recode cntry_num (5 10 11 16 18 =1) (else=0) into cntrdum.
exe.
filter by cntrdum.

crosstabs tables=health by cntry.

crosstabs tables=health by cntry
	/cells=count row column
 /statistics=chisq.

filter off.

** Задание 1. В какой из стран ESS самый высокий и самый низкий процент безработных?
** Задание 2. Исследуйте субъективную оценку состояния здоровья по регионам России.
** Какие выводы можно сделать из результатов?

** Непрерывные переменные.
** Команда descriptives.

desc var=stflife.
desc var=all.

** Средняя удовлетворенность жизнью по странам.

means tables=stflife by cntry.

means tables=stflife by cntry
	/cells= mean median
 /statistics=anova.

* Более подробная статистика.

examine var=stflife.

filter by cntrdum.
examine var=stflife by cntry
		/plot=boxplot
  /statistics=none
  /nototal.
filter off.

** Задание 3. Исследуйте средний уровень религиозности по странам. Проинтерпретируйте результаты.
** Нарисуйте коробчатую диаграмму для трех стран с наивысшим и трех стран с наименьшим уровнем
** религиозности.
** Задание 4. Исследуйте средний уровень удовлетворенности жизни в регионах России. Нарисуйте коробчатую 
** диаграмму распределения удовлетворенности жизнью по регионам.

** Задание 5. Сравните процент людей с высшим образованием в разных странах. Проинтерпретируйте результаты.
** Задание 6. Сравните процент людей с высшим образованием в разных странах в возрастной группе 23-35 лет..

******************************************

* Использование Chart Builder.

**** Столбиковые диаграммы.

GRAPH
  /BAR(SIMPLE)=PCT BY health.

GRAPH
  /BAR(GROUPED)=PCT BY health BY gndr.

*** Гистрограммы.

GRAPH
  /HISTOGRAM=agea.

*** Линейные диаграммы.

GRAPH
  /LINE(SIMPLE)=PCT BY agea.

** Диаграммы рассеивания.

GRAPH
  /SCATTERPLOT(BIVAR)=agea WITH stflife
  /MISSING=LISTWISE.

* Задание 7. Постройте разные типы диаграмм для переменных в базе данных.

